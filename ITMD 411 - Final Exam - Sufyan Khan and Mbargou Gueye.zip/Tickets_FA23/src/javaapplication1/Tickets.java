/*
 * Author: Sufyan Khan and Mbargou Gueye
 * Date: 12/06/2023
 * File: Tickets.java
*/
package javaapplication1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

public class Tickets extends JFrame implements ActionListener {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Dao dao = new Dao();
    boolean chkIfAdmin = false;

    private JMenu mnuFile = new JMenu("File");
    private JMenu mnuAdmin = new JMenu("Admin");
    private JMenu mnuTickets = new JMenu("Tickets");

    JMenuItem mnuItemExit;
    JMenuItem mnuItemRefresh;
    JMenuItem mnuItemDelete;
    JMenuItem mnuItemOpenTicket;
    JMenuItem mnuItemSelectTicket;
    JMenuItem mnuItemAddTicket;
    JMenuItem mnuItemCloseTicket; // Renamed from mnuItemUpdateTicket
    JMenuItem mnuItemViewTicketStatus; // New menu item for Open Ticket Status

    public Tickets(boolean isAdmin) {
        chkIfAdmin = isAdmin;
        createMenu();
        prepareGUI();

        // Show the tables at startup for admin users
        if (chkIfAdmin) {
            openTickets();
        }
    }

    private void createMenu() {
        mnuItemExit = new JMenuItem("Exit");
        mnuFile.add(mnuItemExit);

        mnuItemRefresh = new JMenuItem("Refresh");
        mnuFile.add(mnuItemRefresh);

        if (chkIfAdmin) {
            mnuItemDelete = new JMenuItem("Delete Ticket");
            mnuAdmin.add(mnuItemDelete);

            mnuItemAddTicket = new JMenuItem("Add Ticket");
            mnuAdmin.add(mnuItemAddTicket);

            // Renamed mnuItemUpdateTicket to mnuItemCloseTicketStatus
            mnuItemCloseTicket = new JMenuItem("Close Ticket");
            mnuAdmin.add(mnuItemCloseTicket); // Adding Close Ticket to Admin menu
            mnuItemCloseTicket.addActionListener(this); // Adding ActionListener for Close Ticket

            mnuItemViewTicketStatus = new JMenuItem("View Ticket Status");
            mnuAdmin.add(mnuItemViewTicketStatus); // Adding View Ticket Status to Admin menu
            mnuItemViewTicketStatus.addActionListener(this); // Adding ActionListener for View Ticket Status
        }

        mnuItemOpenTicket = new JMenuItem("Open Ticket");
        mnuTickets.add(mnuItemOpenTicket);

        mnuItemSelectTicket = new JMenuItem("Select Ticket");
        mnuTickets.add(mnuItemSelectTicket);

        mnuItemExit.addActionListener(this);
        mnuItemRefresh.addActionListener(this);
        if (chkIfAdmin) {
            mnuItemDelete.addActionListener(this);
            mnuItemAddTicket.addActionListener(this);
        }
        mnuItemOpenTicket.addActionListener(this);
        mnuItemSelectTicket.addActionListener(this);
    }

    private void prepareGUI() {
        JMenuBar bar = new JMenuBar();
        bar.add(mnuFile);
        if (chkIfAdmin) {
            bar.add(mnuAdmin);
        }
        bar.add(mnuTickets);
        setJMenuBar(bar);

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(WindowEvent wE) {
                System.exit(0);
            }
        });

        setSize(400, 400);
        getContentPane().setBackground(Color.GREEN);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mnuItemExit) {
            System.exit(0);
        } else if (e.getSource() == mnuItemRefresh) {
            refreshTicketView();
        } else if (e.getSource() == mnuItemSelectTicket) {
            selectTicket();
        } else if (e.getSource() == mnuItemAddTicket) {
            addTicket(); // New action for "Add Ticket" menu item
        } else if (e.getSource() == mnuItemDelete) {
            deleteTicket(); // New action for "Delete Ticket" menu item
        } else if (e.getSource() == mnuItemOpenTicket) {
            openTickets(); // Display tickets for both admin and non-admin users
        } else if (e.getSource() == mnuItemCloseTicket && chkIfAdmin) {
            closeTicketStatus(); // New action for "Close Ticket Status" menu item
        } else if (e.getSource() == mnuItemViewTicketStatus && chkIfAdmin) {
            openTicketStatus(); // New action for "Open Ticket Status" menu item
        }
    }

    private void refreshTicketView() {
        try {
            JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
            jt.setBounds(30, 40, 200, 400);
            jt.setBackground(Color.green);
            jt.setForeground(Color.black);
            jt.getTableHeader().setBackground(Color.BLACK);
            jt.getTableHeader().setForeground(Color.white);
            JScrollPane sp = new JScrollPane(jt);
            getContentPane().removeAll();
            add(sp);
            revalidate();
            repaint();
        } catch (SQLException e1) {
            System.out.println("Ticket view refresh failed.");
            e1.printStackTrace();
        }
    }

    private void selectTicket() {
        JOptionPane.showMessageDialog(null, "Ticket selected!");
        // You can implement the functionality for selecting a ticket here
    }

    private void addTicket() {
        String ticketName = JOptionPane.showInputDialog(null, "Enter your name");
        String ticketDesc = JOptionPane.showInputDialog(null, "Enter a ticket description");

        if (ticketName == null || (ticketName != null && ("".equals(ticketName))) ||
                ticketDesc == null || (ticketDesc != null && ("".equals(ticketDesc)))) {
            JOptionPane.showMessageDialog(null, "Ticket creation failed: empty name / description.");
            System.out.println("Ticket creation failed: empty name / description.");
        } else {
            int id = dao.insertRecords(ticketName, ticketDesc);

            if (id != 0) {
                System.out.println("Ticket ID : " + id + " created successfully.");
                JOptionPane.showMessageDialog(null, "Ticket id: " + id + " created");

                try {
                    JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
                    jt.setBounds(30, 40, 200, 400);
                    jt.setBackground(Color.green);
                    jt.setForeground(Color.white);
                    jt.getTableHeader().setBackground(Color.BLACK);
                    jt.getTableHeader().setForeground(Color.white);
                    JScrollPane sp = new JScrollPane(jt);
                    getContentPane().removeAll(); // Remove existing components
                    add(sp); // Add the new JTable
                    revalidate();
                    repaint();
                } catch (SQLException e1) {
                    System.out.println("Ticket view refresh failed.");
                    e1.printStackTrace();
                }
            } else {
                System.out.println("Ticket creation failed.");
            }
        }
    }

    private void deleteTicket() {
        String ticketId = JOptionPane.showInputDialog(null, "Enter the ticket id to delete the ticket");

        if (ticketId == null || (ticketId != null && ("".equals(ticketId)))) {
            JOptionPane.showMessageDialog(null, "Ticket deletion failed: empty tid.");
            System.out.println("Ticket deletion failed: empty tid.");
        } else {
            int tid = Integer.parseInt(ticketId);
            int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete ticket " + tid + "?", "Warning!", JOptionPane.YES_NO_OPTION);
            if (reply == JOptionPane.YES_OPTION) {
                int id = dao.deleteRecords(tid);
                if (id != 0) {
                    System.out.println("Ticket ID : " + id + " deleted successfully.");
                    JOptionPane.showMessageDialog(null, "Ticket id: " + id + " deleted");

                    // Refresh the JTable
                    try {
                        JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
                        jt.setBounds(30, 40, 200, 400);
                        jt.setBackground(Color.green);
                        jt.setForeground(Color.black);
                        jt.getTableHeader().setBackground(Color.BLACK);
                        jt.getTableHeader().setForeground(Color.white);
                        JScrollPane sp = new JScrollPane(jt);
                        getContentPane().removeAll(); // Remove existing components
                        add(sp); // Add the new JTable
                        revalidate();
                        repaint();
                    } catch (SQLException e1) {
                        System.out.println("Ticket view refresh failed.");
                        e1.printStackTrace();
                    }
                } else {
                    System.out.println("Ticket cannot be deleted!!!");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ticket " + tid + " was not deleted.");
            }
        }
    }

    // Existing methods for updateTicket(), openTicketStatus(), and other operations remain unchanged.

    private void closeTicketStatus() {
        String ticketIdInput = JOptionPane.showInputDialog(null, "Enter the ticket ID to close the ticket");

        if (ticketIdInput == null || (ticketIdInput != null && ("".equals(ticketIdInput)))) {
            JOptionPane.showMessageDialog(null, "Ticket ID is empty.");
            System.out.println("Ticket ID is empty.");
        } else {
            int ticketId = Integer.parseInt(ticketIdInput);

            // Check if the ticket ID exists before updating its status
            boolean ticketExists = dao.checkTicketExists(ticketId);

            if (ticketExists) {
                // Assuming 'Close' is the status to be set
                boolean statusUpdated = dao.updateTicketStatus(ticketId, "CLOSE");

                if (statusUpdated) {
                    System.out.println("Ticket ID : " + ticketId + " status updated successfully to 'CLOSE'.");
                    JOptionPane.showMessageDialog(null, "Ticket ID: " + ticketId + " status updated to 'CLOSE'");

                    // Refresh the JTable
                    refreshTicketView();
                } else {
                    System.out.println("Failed to update ticket status.");
                    JOptionPane.showMessageDialog(null, "Failed to update ticket status.");
                }
            } else {
                System.out.println("Ticket ID: " + ticketId + " does not exist.");
                JOptionPane.showMessageDialog(null, "Ticket ID: " + ticketId + " does not exist.");
            }
        }
    }

    private void openTicketStatus() {
        String ticketIdInput = JOptionPane.showInputDialog(null, "Enter the ticket ID to open the ticket");

        if (ticketIdInput == null || (ticketIdInput != null && ("".equals(ticketIdInput)))) {
            JOptionPane.showMessageDialog(null, "Ticket ID is empty.");
            System.out.println("Ticket ID is empty.");
        } else {
            int ticketId = Integer.parseInt(ticketIdInput);

            // Check if the ticket ID exists before updating its status
            boolean ticketExists = dao.checkTicketExists(ticketId);

            if (ticketExists) {
                // Assuming 'Open' is the status to be set
                boolean statusUpdated = dao.updateTicketStatus(ticketId, "OPEN");

                if (statusUpdated) {
                    System.out.println("Ticket ID : " + ticketId + " status updated successfully to 'OPEN'.");
                    JOptionPane.showMessageDialog(null, "Ticket ID: " + ticketId + " status updated to 'OPEN'");

                    // Refresh the JTable
                    refreshTicketView();
                } else {
                    System.out.println("Failed to update ticket status.");
                    JOptionPane.showMessageDialog(null, "Failed to update ticket status.");
                }
            } else {
                System.out.println("Ticket ID: " + ticketId + " does not exist.");
                JOptionPane.showMessageDialog(null, "Ticket ID: " + ticketId + " does not exist.");
            }
        }
    }

    private void openTickets() {
        try {
            JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
            jt.setBounds(30, 40, 200, 400);
            jt.setBackground(Color.green);
            jt.setForeground(Color.black);
            jt.getTableHeader().setBackground(Color.BLACK);
            jt.getTableHeader().setForeground(Color.white);
            JScrollPane sp = new JScrollPane(jt);
            getContentPane().removeAll();
            add(sp);
            revalidate();
            repaint();
        } catch (SQLException e1) {
            System.out.println("Ticket view failed for admin.");
            e1.printStackTrace();
        }
    }

    public static void main(String[] args) {
    }
}
